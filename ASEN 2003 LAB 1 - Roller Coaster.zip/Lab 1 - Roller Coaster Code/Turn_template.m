clc; close all
%% User Inputs
r = 50;
bank_angle = 20*pi/180;
turn_dir = 1;
pos_in = [10 0 0];
vel_in = [49.5227 0 0];
h0 = 125;
n = 100;

%%%%%%%%%%%% MATLAB Grader Inputs - DO NOT CHANGE %%%%%%%%%%%
path_ref = NaN;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Solution
[path, distance, vel_out, g_forces] = banked_turn(vel_in, pos_in, n, r, turn_dir, bank_angle, h0, path_ref);

%% Visualization

% Plot path
figure
sgtitle("Paths for r=" + r + ", turndir=" + turn_dir)

subplot(3,1,1)
plot(path(:,1), 'b','linewidth', 1.5)
title('Roller Coaster X-Dir Path - Reference Solution and Your Solution')
grid on

subplot(3,1,2)
plot(path(:,2), 'b','linewidth', 1.5)
title('Roller Coaster Y-Dir Path - Reference Solution and Your Solution')
grid on

subplot(3,1,3)
plot(path(:,3), 'b','linewidth', 1.5)
title('Roller Coaster Z-Dir Path - Reference Solution and Your Solution')
grid on

% Plot gs 
figure
grid on
hold on
plot(distance, g_forces(:,3), 'linewidth', 1.5)
plot(distance, g_forces(:,2), 'linewidth', 1.5)
plot(distance, g_forces(:,1), 'linewidth', 1.5)
title("Gs vs Distance along Element for r=" + r + ", turndir=" + turn_dir)
legend('Vertical Gs', 'Lateral Gs', 'Front/Back Gs')
ylabel('g''s)')
xlabel('Distance(m)')
grid on

function [path, distance, vel_out, g_s] = banked_turn(vel_in, pos_in, n, r, turn_dir, bank_angle, h0, path_ref)
    

    % Running sequence as normal
    [path, distance, vel_out] = bankedTurn_compute_path(pos_in, vel_in, n, turn_dir, r, h0);
    
    if isnan(path_ref)
        % Running sequence as normal
        g_s = bankedTurn_compute_g_s(path, h0, r, turn_dir, bank_angle);
    else
        % Using dependent input as reference... used to bypass unimplemented functions
        g_s = bankedTurn_compute_g_s(path, h0, r, turn_dir, bank_angle);
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% COMPLETE FUNCTIONS BELOW %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [path, distance, vel_out] = bankedTurn_compute_path(pos_in, vel_in, n, turn_dir, r, h0)
 
     %create theta vector for the turn and the xyz coordinates.  Make sure the
    %loop starts at the beginning x, y, and z coordinates
    xin = pos_in(1);
    yin = pos_in(2);
    zin = pos_in(3);
    
    % starting velocities
    vx = vel_in(1);
    vy = vel_in(2);
    vz = vel_in(3);
    
    % starting angle of loop
    theta_in = sign(vx)*pi/2 + sign(vy)*(pi/2+sign(vy)*pi/2);
    theta_vec = linspace(theta_in, theta_in-pi*sign(turn_dir), n);
        
    % converting theta to xy position - split into cw and ccw case
    if turn_dir ==-1 %ccw
        x = -r*cos(theta_vec) + r*cos(theta_in) + xin;
        y = -r*sin(theta_vec) + r*sin(theta_in) + yin; 
    else %cw
        x = r*cos(theta_vec) - r*cos(theta_in) + xin;
        y = r*sin(theta_vec) -  r*sin(theta_in) + yin;         
    end
    
    z = zin*ones(length(x),1);

    path = [x',y',z];
    
    % computed at each point along loop
    distance = theta_vec'*r;
    
    %[vx vy vz] at loop exit
    vel_out = [vx,-vy,vz];
end

function g_s = bankedTurn_compute_g_s(path, h0, r, turn_dir, bank_angle)
    % Number of elements in path matrix
    z = path(:,3);
    n = length(z);
    
    % hint: solve system of equations for F_normal and F_lateral
    g = 9.81;
    v = sqrt(2*g*(h0-z(1)));
    F = [cos(bank_angle) -sin(bank_angle); -sin(bank_angle) -cos(bank_angle)];
    b = [g; -(v^2)/r];
    X = F\b;

    %Compile the g forces and xyz coordinates into the matrices to be outputted
    %Gs matrix [front/back, left/right, up/down]... Front, left and up are defined as positive
    g_s = [zeros(n,1),-sign(turn_dir)*(X(2)/g)*ones(n,1),(X(1)/g)*ones(n,1)];
end

