%% Starting Parameters
clc; close all
h0 = 125;
pos_in = [0, 0, h0];
n = 100; % number of elements for each track feature

%
%%%%%%%%%%%%%%%%%%% PATH CREATION %%%%%%%%%%%%%%%%%%%%
% Call each track element in succession. Output velocity becomes input velocity of
% next element. Last point in output path becomes pos_in for next element.
% Append path, distance, and g_s outputs to variables of the same name for full coaster. 
%% Element 1: Downward Ramp %%
d = 30;
theta = -pi/4;
[path, distance, vel_out, g_s] = ramp(pos_in, h0, d, theta, n);

%% Transition 1 %%
%transition params
vel_in = vel_out;
pos_in = path(end,:);
vel_exit_unitvec = [1 0 0];
r = 10;
% call transition here - modify if your function is different
[~, ~, ~, path(end+1:end+n,:), distance_el, vel_out, g_s(end+1:end+n,:)] = ...
    transition(vel_in, pos_in, vel_exit_unitvec, r, -1,h0, n, NaN,NaN,NaN);
distance(end+1:end+n) = distance_el + distance(end);

%% Element 2: Banked Turn %%
% turn params
bank_angle = pi/4;
turn_dir = 1;
vel_in = vel_out;
pos_in = path(end,:);
r = 10;
% call banked turn here - modify if your function is different
[path(end+1:end+n,:), distance_el, vel_out, g_s(end+1:end+n,:)] ...
    = banked_turn(vel_in, pos_in, n, r, turn_dir, bank_angle, h0, NaN);
distance(end+1:end+n) = distance_el + distance(end);

%% Transistion 2 %%
vel_in = vel_out;
vel_in(3) = round(vel_in(3)); %transition angles can be sensitive to small errors in vel so we round
pos_in = path(end,:);
vel_exit_unitvec = [-1 0 1];
r = 10;
% call transition here
% modify if your function is different
[~, ~, ~, path(end+1:end+n,:), distance_el, vel_out, g_s(end+1:end+n,:)] = ...
    transition(vel_in, pos_in, vel_exit_unitvec, r, 1, h0, n, NaN,NaN,NaN);
distance(end+1:end+n) = distance_el + distance(end);

%% Element 3: Zero-G Parabola %%
vel_in = vel_out;
pos_in = path(end,:);
a = -9.81; % zero-g
d = 50;
% call parabola here
% modify if your function is different
[path(end+1:end+n,:), distance_el, vel_out, g_s(end+1:end+n,:)]...
    = parabola(vel_in, pos_in, n, a, d, h0, NaN,NaN);
distance(end+1:end+n) = distance_el + distance(end);

%% Transition 3 %%
vel_in = vel_out;
pos_in = path(end,:);
vel_exit_unitvec = [-1 0 0];
r = 20;
% call transition here
% modify if your function is different
[~, ~, ~, path(end+1:end+n,:), distance_el, vel_out, g_s(end+1:end+n,:)] = ...
    transition(vel_in, pos_in, vel_exit_unitvec, r, 1, h0, n, NaN,NaN,NaN);
distance(end+1:end+n) = distance_el + distance(end);

%% Element 4: Banked Turn %%
bank_angle = pi/4;
turn_dir = 1;
vel_in = vel_out;
pos_in = path(end,:);
r = 40;
% call banked turn here
% modify if your function is different
[path(end+1:end+n,:), distance_el, vel_out, g_s(end+1:end+n,:)] ...
    = banked_turn(vel_in, pos_in, n, r, turn_dir, bank_angle, h0, NaN);
distance(end+1:end+n) = distance_el + distance(end);

%% Element 5: Circular Loop %%
prop = 1;
r = 17;
vel_in = vel_out;
pos_in = path(end,:);
% call circular loop here
% modify if your function is different
[~, path(end+1:end+n,:), distance_el, ~, vel_out, g_s(end+1:end+n,:)] =...
    loop(vel_in, pos_in, n, prop, r, h0, NaN,NaN,NaN);
distance(end+1:end+n) = distance_el + distance(end);

%% Element 6: Braking Section %%
vel_in = vel_out;
pos_in = path(end,:);
d = 50;
% call braking section here
% modify if your function is different
[theta_in, path(end+1:end+n,:), distance_el, vel_out, g_s(end+1:end+n,:)]...
    = braking(vel_in, pos_in, n, d, h0, NaN, NaN);
distance(end+1:end+n) = distance_el + distance(end);

%%%%%%%%%%%%%%%% PATH VISUALIZATION %%%%%%%%%%%%%%%
%% 3D plot track
figure
hold on
plot3(path(:,1),path(:,2),path(:,3),'Color','[0.8500 0.3250 0.0980]', 'linewidth', 2)
plot3(path(1,1),path(1,2),path(1,3), 'go', 'linewidth', 2);
plot3(path(end,1),path(end,2),path(end,3), 'ro', 'linewidth', 2);
grid on
title('Path of Rollercoaster')
xlabel('x-direction(m)')
ylabel('y-direction(m)')
zlabel('z-direction(m)')
legend('Path','Start','Finish')
axis equal
view([-.4 -1 .45])

%% Plot Gs(vertical, lateral and horizontal)
% horizontal
figure
hold on
grid on
plot(distance, g_s(:,1),'Color','[0.8500 0.3250 0.0980]', 'linewidth', 1.5)
plot(distance, ones(1,length(distance))*5, 'r--', 'linewidth', 1.5)
plot(distance, -ones(1,length(distance))*4, 'r--', 'linewidth', 1.5)
legend('Gs','Allowable Gs Bound')
title('Horizontal Gs vs Distance Traveled along Track')
xlabel('Distance(m)')
ylabel('Gs')
xlim([0 distance(end)])
ylim([-5 6])

% lateral 
figure
hold on
grid on
plot(distance, g_s(:,2),'Color','[0.8500 0.3250 0.0980]', 'linewidth', 1.5)
plot(distance, ones(1,length(distance))*3, 'r--', 'linewidth', 1.5)
plot(distance, ones(1,length(distance))*(-3), 'r--', 'linewidth', 1.5)
legend('Gs','Allowable Gs Bound')
title('Lateral Gs vs Distance Traveled along Track')
xlabel('Distance(m)')
ylabel('Gs')
xlim([0 distance(end)])
ylim([-4 4])

% vertical
figure
hold on
grid on
plot(distance, g_s(:,3),'Color','[0.8500 0.3250 0.0980]', 'linewidth', 1.5)
plot(distance, ones(1,length(distance))*6, 'r--', 'linewidth', 1.5)
plot(distance, ones(1,length(distance))*(-1), 'r--', 'linewidth', 1.5)
legend('Gs','Allowable Gs Bound')
title('Vertical Gs vs Distance Traveled along Track')
xlabel('Distance(m)')
ylabel('Gs')
xlim([0 distance(end)])
ylim([-2 7])

%% FUNCTIONS - Paste your functions in here

function [path, distance, vel_out, g_s] = ramp(pos_in, h0, d, theta, n)
    %% create path
    distance = (linspace(0, d, n))';
    x = pos_in(1) + cos(theta)*distance;
    z = pos_in(3) + sin(theta)*distance;
    y = ones(n, 1)*pos_in(2);
    
    path = [x y z];
    
    %% vel out 
    speed_out = sqrt(2*9.81*(h0-z(end)));
    vel_out = [cos(theta)*speed_out 0 sin(theta)*speed_out];
    
    %% create g_s
    g_s = [zeros(n, 1) zeros(n, 1) ones(n,1)*cos(theta)];

end

%LOOP
function [theta_in, path, distance, theta_vec, vel_out, g_s] = loop(vel_in, pos_in, n, prop, r, h0, theta_in_ref, path_ref, theta_vec_ref)
    theta_in = loop_starting_angle(vel_in);
    
    if isnan(theta_in_ref)
        [path, distance, theta_vec] = loop_compute_path(pos_in, theta_in, vel_in, n, prop, r);
    else
        [path, distance, theta_vec] = loop_compute_path(pos_in, theta_in_ref, vel_in, n, prop, r);
    end
    
    if isnan(path_ref)
        vel_out = loop_exit_vel(path, theta_vec, h0, vel_in);
    else
        vel_out = loop_exit_vel(path_ref, theta_vec_ref, h0, vel_in);
    end
    
    if isnan(theta_vec_ref)
        g_s = loop_compute_g_s(path, vel_in, h0, theta_vec, r);
    else
        g_s = loop_compute_g_s(path_ref, vel_in, h0, theta_vec_ref, r);
    end
end

function theta_in = loop_starting_angle(vel_in)

    stickyrat = vel_in(3) / vel_in(1);
   
   if vel_in(1) > 1 % Positive initial x-velocity means the loop is counterclockwise
       theta_in = atan(stickyrat);
   else % Otherwise (negative initial x-velocity), the loop is clockwise
       theta_in = atan(abs(stickyrat));
   end
end


function [path, distance, theta_vec] = loop_compute_path(pos_in, theta_in, vel_in, n, prop, r)
    % evenly spaced vector from initial theta, to final theta
    points = 100;
    % prop is the portion of the loop, decimal format
    
    % distance traveled along element path, evaluated at each theta from theta_vec
    if vel_in(1) > 1 % Positive initial x-velocity means the loop is counterclockwise
        theta_out = theta_in + 2*pi*prop;
        theta_vec = linspace(theta_in,theta_out,points);
    else % Otherwise (negative initial x-velocity), the loop is clockwise
        theta_out = theta_in - 2*pi*prop;
        theta_vec = linspace(theta_in,theta_out,points);
    end
   
    distance = linspace(theta_in, theta_out, points)';
    distance = r.*distance;
    x_pos = zeros(100,1);
    y_pos = zeros(100,1);
    z_pos = zeros(100,1);
    
    for i = 1:points
        x_pos(i) = r*sin(theta_vec(i)) + pos_in(1);
        z_pos(i) = -r*cos(theta_vec(i)) + r + pos_in(3);
    end
   
    path = [x_pos, y_pos, z_pos];
end

function vel_out = loop_exit_vel(path, theta, h0, vel_in)
    % compute the velocity vectore leaving the loop element
    
    x_pos = path(:,1);
    y_pos = path(:,2);
    z_pos = path(:,3);
    
    Vel_end = (2*9.81*(h0 - z_pos(end)))^.5;
    
    % use theta and total exit velocity to find vel components
    if theta(end) >= 3*pi/2
        if vel_in(1) > 0
            Vz = -Vel_end*cos(theta(end) - (3*pi/2));
            Vx = Vel_end*sin(theta(end) - (3*pi/2));
        else
            Vz = Vel_end*cos(theta(end) - (3*pi/2));
            Vx = -Vel_end*sin(theta(end) - (3*pi/2));
        end
    elseif theta(end) >= pi
        if vel_in(1) > 0
            Vz = -Vel_end*cos((3*pi/2) - theta(end));
            Vx = -Vel_end*sin((3*pi/2) - theta(end));
        else
            Vz = Vel_end*cos((3*pi/2) - theta(end));
            Vx = Vel_end*sin((3*pi/2) - theta(end));
        end
    elseif theta(end) >= pi/2
        if vel_in(1) > 0
            Vz = Vel_end*sin(theta(end) - (pi/2));
            Vx = -Vel_end*cos(theta(end) - (pi/2));
        else
            Vz = -Vel_end*sin(theta(end) - (pi/2));
            Vx = Vel_end*cos(theta(end) - (pi/2));
        end
    else
        if vel_in(1) > 0
            Vz = Vel_end*sin(theta(end));
            Vx = Vel_end*cos(theta(end));
        else
            Vz = -Vel_end*sin(theta(end));
            Vx = -Vel_end*cos(theta(end));
        end
    end
    Vy = vel_in(2);
    
    vel_out = [Vx, Vy, Vz];
end

function g_s = loop_compute_g_s(path, vel_in, h0, theta, r)
    % Compile the g forces into matrix, evaluated at each theta in theta_vec
    len = length(path(:,1));
    g_s = zeros(len,1);
    Vel_vec = (9.81.*2.*(h0 - path(:,3))).^.5;
    
    for i = 1:len
        if theta(i) >= 3*pi/2
            g_s(i) = cos(2*pi - theta(i)) - (Vel_vec(i)^2)/(9.81*r);
        elseif theta(i) >= pi
            g_s(i) = -sin((3*pi/2) - theta(i)) - (Vel_vec(i)^2)/(9.81*r);
        elseif theta(i) >= pi/2
            g_s(i) = -sin(theta(i) - (pi/2)) - (Vel_vec(i)^2)/(9.81*r);
        else 
            g_s(i) = cos(theta(i)) - (Vel_vec(i)^2)/(9.81*r);
        end
    end
    
    gg = zeros(len,2);
    g_s = [gg, -g_s];

end

%% PARABOLA 
function [path, distance, vel_out, g_s] = parabola(vel_in, pos_in, n, a, d, h0, path_ref, theta_vec_ref)    

    [path, distance] = parabola_compute_path(pos_in, vel_in, n, a, d);
    
    if isnan(path_ref)
        % Running sequence as normal
        vel_out = parabola_exit_vel(path, h0, vel_in, a);
    else
        % Using dependent input as reference... used to bypass unimplemented functions
        vel_out = parabola_exit_vel(path_ref, h0, vel_in, a);
    end
    
    if isnan(path_ref)
        % Running sequence as normal
        g_s = parabola_compute_g_s(path, vel_out, h0, a);
    else
        % Using dependent input as reference... used to bypass unimplemented functions
        g_s = parabola_compute_g_s(path_ref, vel_out, h0, a);
    end
end

function [path, distance] = parabola_compute_path(pos_in, vel_in, n, a, d)
    x_in = pos_in(1,1);
    
    if vel_in(1) >= 0
        x_vect = (linspace(x_in, x_in+d, n))';
    elseif vel_in(1) < 0
        x_vect = (linspace(x_in, x_in-d, n))';
    end
        
    t = abs( (x_vect-x_in)./vel_in(1) );
    z = ( pos_in(:,3) + vel_in(:,3).*t + 0.5*a*t.^2 );
    y_vect = ( pos_in(:,2)*ones(length(z),1) );
    
    
    path = [x_vect , y_vect , z];
    
    % you do not need to find analytical form to compute distance at each point. Hint: think distance formula
    distance = sqrt((x_vect-x_in).^2 + (z - pos_in(:,3)).^2 );
end

function vel_out = parabola_exit_vel(path, h0, vel_in, a)

    % x velocity
    vx = vel_in(1);
    
    % z position
    z = path(:,3);
    
    %vertical displacement along parabola
    dh = h0 - z(end); 
    
    % by conservation of energy - see derivations
    vz = sqrt((2*9.81*dh)-vx^2) * sign(z(end)-z(end-1));
  
    vel_out = [vx 0 vz];    %Velocity vector leaving the parab
end

function g_s = parabola_compute_g_s(path, vel_out, h0, a)
    n = length(path(:,1));

    % Now compute the g-s experienced at every point on the parabola
    z = path(:,3);
    x = path(:,1)-path(1,1);
    speed = sqrt(2*9.81*(h0-z)); %speed at every point along parabola
    
    g = 9.81;
    

    velx = vel_out(1);
    velz = sqrt(speed.^2-vel_out(1)^2);

    % Compile the gs and xyz coordinates into the matrices to be outputted    
    
    g_s = [zeros(3,n)];
end

%% TRANSITION
function [theta_in, theta_exit, theta_vec, path, distance, vel_out, g_s] = transition(vel_in, pos_in, vel_exit, r, dir,h0, n, theta_in_ref, theta_exit_ref, theta_vec_ref)

    [theta_in, theta_exit] = transition_startstop_angles(vel_in, vel_exit, dir);
    
    if isnan(theta_in_ref)
        [path, distance, vel_out, theta_vec] = transition_path(vel_in,vel_exit, pos_in,theta_in, theta_exit, r, dir, h0, n);
    else
        [path, distance, vel_out, theta_vec] = transition_path(vel_in,vel_exit, pos_in,theta_in_ref, theta_exit_ref, r, dir, h0, n);
    end
    
    if isnan(theta_vec_ref)
        g_s = transition_g_s(vel_in, path, theta_vec, r, h0, n);
    else
        g_s = transition_g_s(vel_in, path, theta_vec_ref, r, h0, n);
    end
end

function [theta_in, theta_exit] = transition_startstop_angles(vel_in, vel_exit, dir)
        
        % Assume always going to be bottom half of a circle
        % First, compute the necessary starting angle and stopping angle for the loop

        if dir == 1 % cw
            %split of cw into two seperate cases for initial angle
            if sign(vel_in(3)) ~= -1 
                theta_in = pi - atan2(vel_in(3), vel_in(1)); % see instructional guide for derivation
            else
                theta_in = -(pi+atan2(vel_in(3), vel_in(1)));
            end
            theta_exit = pi - atan2(vel_exit(3), vel_exit(1));
        else %ccw
            theta_in = atan2(vel_in(3),vel_in(1));
            theta_exit = atan2(vel_exit(3), vel_exit(1));
        end
end
    
function [path, distance, vel_out, theta_vec] = transition_path(vel_in, vel_exit, pos_in,theta_in, theta_exit, r, dir, h0, n)
    
    % create vector of theta values
    theta_vec = linspace(theta_in, theta_exit, n);


    xin = pos_in(1);
    yin = pos_in(2);
    zin = pos_in(3);
    
    y = yin*ones(1,n); %Since it's in the xz plane the y values don't change
    
    % Split into cw and ccw cases - derivation in instructional guide
if dir == 1 %cw
        x_center = pos_in(1) + r*sin(theta_in);
        z_center = pos_in(3) + r*cos(theta_in);
        
        x_vect = -(r.*sin(theta_vec))' + x_center;
        y_vect = pos_in(2)*ones(n,1);
        z_vect = -(r.*cos(theta_vec))' + z_center;
        
    else %ccw
        x_center = pos_in(1) - r*sin(theta_in);
        z_center = pos_in(3) + r*cos(theta_in);
        
        x_vect = (r.*sin(theta_vec))' + x_center;
        y_vect = pos_in(2)*ones(n,1);
        z_vect = -(r.*cos(theta_vec))' + z_center;
        
    end
    
    % find distance along track element - use S = rtheta
    distance = abs(theta_vec-theta_vec(1))*r;
    z = z_vect;y = y_vect;x = x_vect;
    path = [x y z];
    
    speed_exit = sqrt(2*9.81*(h0-z(end)));
    
    % two cases addressed: 1) when |vx_exit| = |vz_exit| - 45 degree angle exit, 2) vx_exit or vz_exit = 0
    if abs(vel_exit(1)) == abs(vel_exit(3))
       vel_out = sqrt(2)/2 * vel_exit *speed_exit;
    else
        vel_out = speed_exit * vel_exit;    
    end
end


function g_s = transition_g_s(vel_in, path, theta_vec, r, h0, n)

    vel_current = sqrt(abs( 2*9.81* (h0 - path(:, 3)) ) ) ;
    G_force_z = ( (vel_current.^2)/(r*9.81) + ( cos(theta_vec') ) );

    g_s = [zeros(size(G_force_z)),zeros(size(G_force_z)),G_force_z];  %G-force matrix [front/back, left/right, up/down]
end


%% BANKED TURN
function [path, distance, vel_out, g_s] = banked_turn(vel_in, pos_in, n, r, turn_dir, bank_angle, h0, path_ref)
    
    % Running sequence as normal
    [path, distance, vel_out] = bankedTurn_compute_path(pos_in, vel_in, n, turn_dir, r, h0);
    
    if isnan(path_ref)
        % Running sequence as normal
        g_s = bankedTurn_compute_g_s(path, h0, r, turn_dir, bank_angle);
    else
        % Using dependent input as reference... used to bypass unimplemented functions
        g_s = bankedTurn_compute_g_s(path, h0, r, turn_dir, bank_angle);
    end
end

function [path, distance, vel_out] = bankedTurn_compute_path(pos_in, vel_in, n, turn_dir, r, h0)
    %create theta vector for the turn and the xyz coordinates.  Make sure the
    %loop starts at the beginning x, y, and z coordinates
    xin = pos_in(1);
    yin = pos_in(2);
    zin = pos_in(3);
    
    % starting velocities
    vx = vel_in(1);
    vy = vel_in(2);
    
    % starting angle of loop
    theta_in = sign(vx)*pi/2 + sign(vy)*(pi/2+sign(vy)*pi/2);
    theta_vec = linspace(theta_in, theta_in-pi*sign(turn_dir), n);
        
    % converting theta to xy position - split into cw and ccw case
    if turn_dir ==-1 %ccw
        x = -r*cos(theta_vec) + r*cos(theta_in) + xin;
        y = -r*sin(theta_vec) + r*sin(theta_in) + yin; 
    else %cw
        x = r*cos(theta_vec) - r*cos(theta_in) + xin;
        y = r*sin(theta_vec) -  r*sin(theta_in) + yin;         
    end
    
    % z position does not change
    z = zin*ones(1,n);
    
    %Velocity vector leaving the loop - vel in will only have 1 non-zero comp, negate this
    vel_out = -1 * vel_in; 
    
    % find distance along track element - use S = rtheta
    distance = abs(theta_vec-theta_vec(1))'*r;
    
    path = [x' y' z'];
end

function g_s = bankedTurn_compute_g_s(path, h0, r, turn_dir, angle)
    z = path(:,3);
    n = length(z);
    
    %Now compute the g-forces experienced at every point on the loop
    g = 9.81;                  %Force of gravity [m/s^2]
    vel = sqrt(2*g*(h0-z(1))); %Speed during every point on the loop
    F = [cos(angle) -sin(angle); -sin(angle) -cos(angle)];
    b = [g; -(vel^2)/r];
    X = F\b;

    %Compile the g forces and xyz coordinates into the matrices to be outputted
    %G-force matrix [front/back, left/right, up/down]
    g_s = [zeros(n,1),-sign(turn_dir)*(X(2)/g)*ones(n,1),(X(1)/g)*ones(n,1)];
end

%% BRAKING
function [theta_in, path, distance, vel_out, g_forces] = braking(vel_in, pos_in, n, d, h0, theta_in_ref, path_ref)
    
    theta_in = braking_starting_angle(vel_in);
    
    if isnan(theta_in_ref)
        % Running sequence as normal
        [path, distance, vel_out] = braking_compute_path(pos_in, theta_in, vel_in, n, d);
    else
        % Using dependent input as reference... used to bypass unimplemented functions
        [path, distance, vel_out] = braking_compute_path(pos_in, theta_in_ref, vel_in, n, d);
    end
    
    if isnan(path_ref)
        % Running sequence as normal
        g_forces = braking_compute_g_s(d, n, vel_in);
    else
        % Using dependent input as reference... used to bypass unimplemented functions
        g_forces = braking_compute_g_s(d, n, vel_in);
    end
end

function theta_in = braking_starting_angle(vel_in)
    % The braking section will always be entirely in the x-y plane and the
    % angle is measured positive from the positive x-axis.
    
    % Trig shows theta can be found by taking inverse tangent of components of velocity.
    vx = vel_in(1);
    vy = vel_in(2);
    theta_in = atan2(vy, vx);
    
    % Restrict range of theta from 0-2pi
    if theta_in<0
       theta_in = 2*pi + theta_in;
    end
end

function [path, distance, vel_out] = braking_compute_path(pos_in, theta_in, vel_in, n, d)
    % Assume constant deceleration over entire section, with ending point at v=0
    
    % Height, z, is constant for the entire braking section.
    z = ones(1,n)*pos_in(3);
    
    % Determine the length of the x-component and y-component of the braking section
    % using the starting angle and braking section distance.
    
    delta_x = cos(theta_in);
    delta_y = sin(theta_in);
    
    
    % Find the x and y portions of the path using the fact that we know the starting 
    % position and the length of the braking section of each component.
    x = linspace(pos_in(1), pos_in(1) + delta_x, n);
    y = linspace(pos_in(2), pos_in(2) + delta_y, n);
    
    % Track distance at each n index using discrete differences. Analytical method could 
    % also be derived
    dx = abs(x(2:end)-x(1:end-1));
    dy = abs(y(2:end)-y(1:end-1));
    
    distance = zeros(n,1);
    for i = 2:n
        distance(i) = distance(i-1) + sqrt(dx(i-1)^2 + dy(i-1)^2);
    end
    
    vel_out = [0 0 0];
    z = pos_in(3)*ones(length(x),1);
    path = [x',y',z];
end

function g_s = braking_compute_g_s(d, n, vel_in)    
    % Compile the g-forces in all 3 directions.
    g = 9.81;
    v = norm(vel_in);
    gx = -(v^2)/(2*d*g)*ones(n,1);
    gz = ones(n,1);
    
    g_s = [gx,zeros(n,1),gz];
end
