function [path, distance, vel_out, g_s] = parabola(vel_in, pos_in, n, a, d, h0, path_ref, theta_vec_ref)    

    [path, distance] = parabola_compute_path(pos_in, vel_in, n, a, d);
    
    if isnan(path_ref)
        % Running sequence as normal
        vel_out = parabola_exit_vel(path, h0, vel_in, a);
    else
        % Using dependent input as reference... used to bypass unimplemented functions
        vel_out = parabola_exit_vel(path_ref, h0, vel_in, a);
    end
    
    if isnan(path_ref)
        % Running sequence as normal
        g_s = parabola_compute_g_s(path, vel_out, h0, a);
    else
        % Using dependent input as reference... used to bypass unimplemented functions
        g_s = parabola_compute_g_s(path_ref, vel_out, h0, a);
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% COMPLETE FUNCTIONS BELOW %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function [path, distance] = parabola_compute_path(pos_in, vel_in, n, a, d)
    % create a vector of n equally spaced x-values ranging from x_in to x_in+d. Evaluate parabola at each one of these x locations
    % to create path matrix
   
    x_in = pos_in(1,1);
    
    if vel_in(1) >= 0
        x_vect = (linspace(x_in, x_in+d, n))';
    elseif vel_in(1) < 0
        x_vect = (linspace(x_in, x_in-d, n))';
    end
        
    t = abs( (x_vect-x_in)./vel_in(1) );
    z = ( pos_in(:,3) + vel_in(:,3).*t + 0.5*a*t.^2 );
    y_vect = ( pos_in(:,2)*ones(length(z),1) );
    
    
    path = [x_vect , y_vect , z];
    
    % you do not need to find analytical form to compute distance at each point. Hint: think distance formula
    distance = sqrt((x_vect-x_in).^2 + (z - pos_in(:,3)).^2 );
end

function vel_out = parabola_exit_vel(path, h0, vel_in, a)
    % compute velocity vector leaving parabola
      
    mag_vel_out = sqrt(2*a*abs( path(end,3) - h0) );
    
    x_vel_out = vel_in(1);
    
    y_vel_out = vel_in(2);
    
    z_vel_out = sqrt( (2*a*(path(end,3) - h0)) - vel_in(1)^2);
    
    vel_out = [x_vel_out, y_vel_out, z_vel_out];
end

function g_s = parabola_compute_g_s(path, vel_out, h0, a)

    
    % number of points to comput G's at
    n = length(path(:,1));

    % Compile the gs and xyz coordinates into the matrices to be outputted. Hint: you can leverage what you know about a ballistic trajectory to 
    % create g_s
    
    x_g = zeros(n,1);
    y_g = zeros(n,1);
    z_g = zeros(n,1);
    
    g_s = [x_g, y_g, z_g];   %Gs matrix [front/back, left/right, up/down]
end
